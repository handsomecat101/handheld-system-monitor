﻿System Monitor Widget - hotfix38

How to run:
1. Extract this ZIP to a normal folder.
2. Right-click SystemMonitor.exe > Run as administrator if TDP/Fan controls do not work.
3. If Windows SmartScreen appears, choose More info > Run anyway only if you downloaded it from the official repo.

Known issue:
Fan control is experimental on GPD Win Mini 7840U. If fan does not spin, switch fan mode back to Auto and reboot before heavy gaming.
